
function gateStoreKey(section, slug){ return `gate_admin_${section}_${slug}`; }
function gateRead(key, fallback){ try{ return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch(e){ return fallback; } }
function gateWrite(key, value){ localStorage.setItem(key, JSON.stringify(value)); }

function gateEnsurePlan(){
  const key = "gate_trial_plan";
  let state = gateRead(key, null);
  if(!state){
    const now = new Date();
    const ends = new Date(now.getTime() + 14*24*60*60*1000);
    state = {plan:"FREE_TRIAL", startedAt: now.toISOString(), endsAt: ends.toISOString(), freeQuestions:50};
    gateWrite(key, state);
  }
  return state;
}
function gateSetPlan(plan){
  const st = gateEnsurePlan();
  st.plan = plan;
  gateWrite("gate_trial_plan", st);
  alert("Plan changed to " + plan);
  location.reload();
}
function gateTrialBadgeHTML(){
  const st = gateEnsurePlan();
  const now = new Date();
  const ends = new Date(st.endsAt);
  const days = Math.max(0, Math.ceil((ends-now)/(24*60*60*1000)));
  const active = st.plan !== "FREE_TRIAL" ? "Paid Access" : (now < ends ? "Trial Active" : "Trial Locked");
  return `
    <div class="gate-badges">
      <span class="gate-badge">${active}</span>
      <span class="gate-badge">Plan: ${st.plan}</span>
      <span class="gate-badge">Free Questions: ${st.freeQuestions}</span>
      <span class="gate-badge">Days Left: ${days}</span>
    </div>
  `;
}

function gateEscape(s){
  return String(s || "").replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
}

function gateRenderManager(section, slug){
  const host = document.getElementById("gate-manager-host");
  if(!host) return;
  host.innerHTML = `
    ${section === 'free_trial' || section === 'bundles' ? gateTrialBadgeHTML() : ''}
    <div class="gate-manager">
      <h3>Admin Page Manager</h3>
      <div class="row">
        <div><label>Title</label><input id="gate-title" placeholder="Enter title"></div>
        <div><label>Image Upload</label><input id="gate-image" type="file" accept="image/*"></div>
      </div>
      <div style="margin-top:.8rem"><label>Description / Details</label><textarea id="gate-desc" placeholder="Enter details, content, notes, or updates"></textarea></div>
      <div style="margin-top:.8rem"><label>Price / Amount (optional)</label><input id="gate-price" placeholder="Optional price or amount"></div>
      <div class="btnrow">
        <button class="gate-admin-btn" style="background:var(--gold) !important;color:#0d1b2e !important;font-size:.95rem;padding:.65rem 1.6rem;" onclick="gateAddItem('${section}','${slug}')">📢 POST</button>
        <button class="gate-admin-btn alt" onclick="gateRenderItems('${section}','${slug}')">Refresh</button>
        ${(section === 'free_trial' || section === 'bundles') ? `
          <button class="gate-admin-btn alt" onclick="gateSetPlan('FREE_TRIAL')">Free Trial</button>
          <button class="gate-admin-btn alt" onclick="gateSetPlan('$250_PLAN')">$250 Plan</button>
          <button class="gate-admin-btn alt" onclick="gateSetPlan('$500_PLAN')">$500 Plan</button>
        ` : ``}
      </div>
      <div id="gate-content-list"></div>
    </div>
  `;
  gateRenderItems(section, slug);
}

function gateAddItem(section, slug){
  const key = gateStoreKey(section, slug);
  const items = gateRead(key, []);
  const title = document.getElementById("gate-title").value.trim();
  const desc = document.getElementById("gate-desc").value.trim();
  const price = document.getElementById("gate-price").value.trim();
  const file = document.getElementById("gate-image").files[0];
  if(!title && !desc && !file && !price){ alert('Please fill in a title or description first.'); return; }
  const save = (img="") => {
    items.unshift({id:"id_"+Date.now()+"_"+Math.random().toString(16).slice(2), title, desc, price, img, createdAt:new Date().toISOString()});
    gateWrite(key, items);
    document.getElementById("gate-title").value = "";
    document.getElementById("gate-desc").value = "";
    document.getElementById("gate-price").value = "";
    document.getElementById("gate-image").value = "";
    gateRenderItems(section, slug);
  };
  if(file){
    const fr = new FileReader();
    fr.onload = e => save(e.target.result);
    fr.readAsDataURL(file);
  } else save("");
}

function gateRenderItems(section, slug){
  const list = document.getElementById("gate-content-list");
  if(!list) return;
  const items = gateRead(gateStoreKey(section, slug), []);
  if(!items.length){
    list.innerHTML = '';  // Empty for public; admin sees help text via admin panel
    return;
  }
  list.innerHTML = items.map(it => `
    <div class="gate-admin-card">
      <div class="gate-badges">
        <span class="gate-badge">${new Date(it.createdAt).toLocaleString()}</span>
        ${it.price ? `<span class="gate-badge">Price: ${gateEscape(it.price)}</span>` : ``}
      </div>
      <h4>${gateEscape(it.title || "(Untitled)")}</h4>
      <div>${gateEscape(it.desc || "")}</div>
      ${it.img ? `<img src="${it.img}" alt="uploaded image">` : ``}
      <div class="btnrow">
        <button class="gate-admin-btn alt" onclick="gateEditItem('${section}','${slug}','${it.id}')">Edit</button>
        <button class="gate-admin-btn alt" onclick="gateDeleteItem('${section}','${slug}','${it.id}')">Delete</button>
      </div>
    </div>
  `).join("");
}

function gateDeleteItem(section, slug, id){
  const key = gateStoreKey(section, slug);
  gateWrite(key, gateRead(key, []).filter(x => x.id !== id));
  gateRenderItems(section, slug);
}
function gateEditItem(section, slug, id){
  const key = gateStoreKey(section, slug);
  const items = gateRead(key, []);
  const item = items.find(x => x.id === id);
  if(!item) return;
  const title = prompt("Edit title", item.title || "");
  if(title === null) return;
  const desc = prompt("Edit description", item.desc || "");
  if(desc === null) return;
  const price = prompt("Edit price / amount", item.price || "");
  if(price === null) return;
  item.title = title; item.desc = desc; item.price = price;
  gateWrite(key, items);
  gateRenderItems(section, slug);
}


/* ---- Full admin controls ---- */
function gateDefaultStatus(){ return "draft"; }
function gateStatusBadge(status){
  const map = {
    draft: "Draft",
    approved: "Approved",
    verified: "Verified",
    suspended: "Suspended",
    archived: "Archived"
  };
  return map[status] || status;
}
function gateStatusColor(status){
  const colors = {
    draft: "rgba(201,168,76,.08)",
    approved: "rgba(45,122,79,.16)",
    verified: "rgba(34,211,238,.16)",
    suspended: "rgba(139,32,32,.16)",
    archived: "rgba(184,168,138,.12)"
  };
  return colors[status] || "rgba(201,168,76,.08)";
}
function gateEnsureRegistry(){
  const key = "gate_admin_registry";
  let reg = gateRead(key, null);
  if(!reg){
    reg = {
      role: "admin",
      permissions: {
        add: true, remove: true, edit: true, change: true, upload: true,
        approve: true, verify: true, delete: true, suspend: true, restore: true
      }
    };
    gateWrite(key, reg);
  }
  return reg;
}
function gateRenderAdminSummary(hostId="gate-admin-summary"){
  const host = document.getElementById(hostId);
  if(!host) return;
  const reg = gateEnsureRegistry();
  host.innerHTML = `
    <div class="gate-badges">
      <span class="gate-badge">Role: ${reg.role.toUpperCase()}</span>
      ${Object.keys(reg.permissions).map(k => `<span class="gate-badge">${k}</span>`).join("")}
    </div>
  `;
}

function gateApproveItem(section, slug, id){ gateSetItemStatus(section, slug, id, "approved"); }
function gateVerifyItem(section, slug, id){ gateSetItemStatus(section, slug, id, "verified"); }
function gateSuspendItem(section, slug, id){ gateSetItemStatus(section, slug, id, "suspended"); }
function gateArchiveItem(section, slug, id){ gateSetItemStatus(section, slug, id, "archived"); }
function gateRestoreItem(section, slug, id){ gateSetItemStatus(section, slug, id, "draft"); }

function gateSetItemStatus(section, slug, id, status){
  const key = gateStoreKey(section, slug);
  const items = gateRead(key, []);
  const item = items.find(x => x.id === id);
  if(!item) return;
  item.status = status;
  item.updatedAt = new Date().toISOString();
  gateWrite(key, items);
  gateRenderItems(section, slug);
}

const gateOldAddItem = gateAddItem;
gateAddItem = function(section, slug){
  const key = gateStoreKey(section, slug);
  const items = gateRead(key, []);
  const title = document.getElementById("gate-title").value.trim();
  const desc = document.getElementById("gate-desc").value.trim();
  const price = document.getElementById("gate-price").value.trim();
  const file = document.getElementById("gate-image").files[0];
  if(!title && !desc && !file && !price){ alert('Please fill in a title or description first.'); return; }
  const save = (img="") => {
    items.unshift({
      id:"id_"+Date.now()+"_"+Math.random().toString(16).slice(2),
      title, desc, price, img,
      createdAt:new Date().toISOString(),
      updatedAt:new Date().toISOString(),
      status: gateDefaultStatus(),
      approved:false,
      verified:false,
      suspended:false
    });
    gateWrite(key, items);
    document.getElementById("gate-title").value = "";
    document.getElementById("gate-desc").value = "";
    document.getElementById("gate-price").value = "";
    document.getElementById("gate-image").value = "";
    gateRenderItems(section, slug);
  };
  if(file){
    const fr = new FileReader();
    fr.onload = e => save(e.target.result);
    fr.readAsDataURL(file);
  } else save("");
}

gateRenderItems = function(section, slug){
  const list = document.getElementById("gate-content-list");
  if(!list) return;
  const items = gateRead(gateStoreKey(section, slug), []);
  if(!items.length){
    list.innerHTML = '';  // Empty for public; admin sees help text via admin panel
    return;
  }
  list.innerHTML = items.map(it => `
    <div class="gate-admin-card">
      <div class="gate-badges">
        <span class="gate-badge" style="background:${gateStatusColor(it.status||'draft')}">${gateStatusBadge(it.status||'draft')}</span>
        <span class="gate-badge">Created: ${new Date(it.createdAt).toLocaleString()}</span>
        ${it.updatedAt ? `<span class="gate-badge">Updated: ${new Date(it.updatedAt).toLocaleString()}</span>` : ``}
        ${it.price ? `<span class="gate-badge">Price: ${gateEscape(it.price)}</span>` : ``}
      </div>
      <h4>${gateEscape(it.title || "(Untitled)")}</h4>
      <div>${gateEscape(it.desc || "")}</div>
      ${it.img ? `<img src="${it.img}" alt="uploaded image">` : ``}
      <div class="btnrow">
        <button class="gate-admin-btn alt" onclick="gateEditItem('${section}','${slug}','${it.id}')">Edit</button>
        <button class="gate-admin-btn alt" onclick="gateApproveItem('${section}','${slug}','${it.id}')">Approve</button>
        <button class="gate-admin-btn alt" onclick="gateVerifyItem('${section}','${slug}','${it.id}')">Verify</button>
        <button class="gate-admin-btn alt" onclick="gateSuspendItem('${section}','${slug}','${it.id}')">Suspend</button>
        <button class="gate-admin-btn alt" onclick="gateArchiveItem('${section}','${slug}','${it.id}')">Archive</button>
        <button class="gate-admin-btn alt" onclick="gateRestoreItem('${section}','${slug}','${it.id}')">Restore</button>
        <button class="gate-admin-btn alt" onclick="gateDeleteItem('${section}','${slug}','${it.id}')">Delete</button>
      </div>
    </div>
  `).join("");
}

gateEditItem = function(section, slug, id){
  const key = gateStoreKey(section, slug);
  const items = gateRead(key, []);
  const item = items.find(x => x.id === id);
  if(!item) return;
  const title = prompt("Edit title", item.title || "");
  if(title === null) return;
  const desc = prompt("Edit description", item.desc || "");
  if(desc === null) return;
  const price = prompt("Edit price / amount", item.price || "");
  if(price === null) return;
  const status = prompt("Change status: draft / approved / verified / suspended / archived", item.status || "draft");
  if(status === null) return;
  item.title = title;
  item.desc = desc;
  item.price = price;
  item.status = status || "draft";
  item.updatedAt = new Date().toISOString();
  gateWrite(key, items);
  gateRenderItems(section, slug);
}

const gateOldRenderManager = gateRenderManager;
gateRenderManager = function(section, slug){
  const host = document.getElementById("gate-manager-host");
  if(!host) return;
  host.innerHTML = `
    ${section === 'free_trial' || section === 'bundles' ? gateTrialBadgeHTML() : ''}
    <div id="gate-admin-summary"></div>
    <div class="gate-manager">
      <h3>Admin Page Manager — Full Access</h3>
      <div class="row">
        <div><label>Title</label><input id="gate-title" placeholder="Enter title"></div>
        <div><label>Image Upload</label><input id="gate-image" type="file" accept="image/*"></div>
      </div>
      <div style="margin-top:.8rem"><label>Description / Details</label><textarea id="gate-desc" placeholder="Enter details, content, notes, or updates"></textarea></div>
      <div style="margin-top:.8rem"><label>Price / Amount (optional)</label><input id="gate-price" placeholder="Optional price or amount"></div>
      <div class="btnrow">
        <button class="gate-admin-btn" style="background:var(--gold) !important;color:#0d1b2e !important;font-size:.95rem;" onclick="gateAddItem('${section}','${slug}')">📢 POST</button>
        <button class="gate-admin-btn alt" onclick="gateRenderItems('${section}','${slug}')">Refresh</button>
        ${(section === 'free_trial' || section === 'bundles') ? `
          <button class="gate-admin-btn alt" onclick="gateSetPlan('FREE_TRIAL')">Free Trial</button>
          <button class="gate-admin-btn alt" onclick="gateSetPlan('$250_PLAN')">$250 Plan</button>
          <button class="gate-admin-btn alt" onclick="gateSetPlan('$500_PLAN')">$500 Plan</button>
        ` : ``}
      </div>
      <div id="gate-content-list"></div>
    </div>
  `;
  gateRenderAdminSummary();
  gateRenderItems(section, slug);
}
